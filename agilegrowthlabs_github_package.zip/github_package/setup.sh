#!/bin/bash

echo "⚡ AgileGrowthLabs Content Engine - Mac/Linux Setup"
echo "================================================"

echo "📦 Installing Python packages..."
pip3 install -r requirements.txt

if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cp .env.example .env
    echo "⚠️  Please edit .env and add your OpenAI API key"
else
    echo "✅ .env file already exists"
fi

echo ""
echo "🎉 Setup Complete!"
echo "================================================"
echo "📝 Next steps:"
echo "1. Edit the .env file and add your OpenAI API key"
echo "   Get your key from: https://platform.openai.com/api-keys"
echo "2. Run: python3 start.py"
echo "3. Open your browser to: http://localhost:5001"
echo ""

