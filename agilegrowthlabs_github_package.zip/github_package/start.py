#!/usr/bin/env python3
"""
AgileGrowthLabs Content Engine - Startup Script
Simple script to check configuration and start the application
"""

import os
import sys
from dotenv import load_dotenv

def check_requirements():
    """Check if all requirements are met"""
    print("🔍 Checking requirements...")
    
    # Check Python version
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        return False
    print("✅ Python version OK")
    
    # Check if .env file exists
    if not os.path.exists('.env'):
        print("⚠️  No .env file found")
        print("📝 Please copy .env.example to .env and add your OpenAI API key")
        return False
    print("✅ .env file found")
    
    # Load environment variables
    load_dotenv()
    
    # Check OpenAI API key
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key or api_key == 'your_openai_api_key_here':
        print("❌ OpenAI API key not configured")
        print("📝 Please add your OpenAI API key to the .env file")
        print("🔗 Get your API key from: https://platform.openai.com/api-keys")
        return False
    print("✅ OpenAI API key configured")
    
    return True

def start_application():
    """Start the Flask application"""
    print("\n🚀 Starting AgileGrowthLabs Content Engine...")
    print("📱 Open your browser to: http://localhost:5001")
    print("⏹️  Press Ctrl+C to stop the server")
    print("-" * 50)
    
    # Import and run the app
    from app import app
    app.run(host='0.0.0.0', port=5001, debug=True)

if __name__ == '__main__':
    print("⚡ AgileGrowthLabs Content Engine")
    print("=" * 50)
    
    if check_requirements():
        start_application()
    else:
        print("\n❌ Setup incomplete. Please fix the issues above and try again.")
        sys.exit(1)

