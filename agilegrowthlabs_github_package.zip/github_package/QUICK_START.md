# 🚀 Quick Start Guide - AgileGrowthLabs Content Engine

## ⚡ Get Running in 3 Minutes

### Step 1: Setup (Choose your method)

**Windows Users:**
```
Double-click: setup.bat
```

**Mac/Linux Users:**
```
./setup.sh
```

**Manual Setup:**
```
pip install -r requirements.txt
cp .env.example .env
```

### Step 2: Add Your OpenAI API Key

1. Open the `.env` file in any text editor
2. Replace `your_openai_api_key_here` with your actual API key
3. Get your API key from: https://platform.openai.com/api-keys

Example:
```
OPENAI_API_KEY=sk-your-actual-key-here
```

### Step 3: Start the Engine

```
python start.py
```

### Step 4: Open Your Browser

Go to: http://localhost:5001

## 🎯 What You Can Do

### Generate Content
- **LinkedIn Posts**: Professional, engaging posts with VIRAL framework
- **Twitter Threads**: Multi-tweet sequences with hooks
- **Blog Outlines**: SEO-optimized long-form content structures
- **Email Newsletters**: Lead generation focused content

### Research & Intelligence
- Find trending topics in your industry
- Identify engagement opportunities
- Monitor influencer activities
- Get market intelligence

### Dan Martell Framework
- Execute complete content flywheel
- Research → Create → Repurpose → Distribute → Engage
- 8x content multiplier system

## 🆘 Troubleshooting

**"No module named 'openai'"**
```
pip install -r requirements.txt
```

**"No OpenAI API key found"**
- Check your .env file
- Make sure you copied your API key correctly
- Ensure no extra spaces or quotes

**"Port already in use"**
- Close other applications using port 5001
- Or change the port in app.py

**"Permission denied"**
- On Mac/Linux: `chmod +x setup.sh start.py`

## 💡 Tips

- Start with LinkedIn posts - they work great
- Use the research function to find trending topics
- Customize the prompts in app.py for your voice
- The system learns from your preferences

## 🔧 Customization

Edit these files to customize:
- `.env` - Your API keys and company info
- `app.py` - Content prompts and branding
- `README.md` - Full documentation

## 📞 Need Help?

Check the full README.md for detailed instructions and troubleshooting.

**You're ready to generate high-quality content for AgileGrowthLabs.com!**

