#!/usr/bin/env python3
"""
AgileGrowthLabs Content Engine - Local Version
Real content generation with OpenAI integration for your own use
"""

import os
from dotenv import load_dotenv
import openai
from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
from datetime import datetime
import json
import traceback

# Load environment variables from .env file
load_dotenv()

# Initialize OpenAI with your API key
openai.api_key = os.getenv('OPENAI_API_KEY')

if not openai.api_key:
    print("⚠️  WARNING: No OpenAI API key found!")
    print("Please create a .env file with your OPENAI_API_KEY")
    print("See .env.example for the template")

app = Flask(__name__)
CORS(app)

app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'agilegrowthlabs-content-engine-local')
app.config['DEBUG'] = os.getenv('FLASK_DEBUG', 'True').lower() == 'true'

# Company configuration from environment variables
COMPANY_NAME = os.getenv('COMPANY_NAME', 'AgileGrowthLabs')
COMPANY_URL = os.getenv('COMPANY_URL', 'https://agilegrowthlabs.com')
COMPANY_TAGLINE = os.getenv('COMPANY_TAGLINE', 'Grow, Exit, Equity Experts')

# Simple HTML with inline JavaScript
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AgileGrowthLabs Content Engine - LOCAL VERSION</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            color: #333;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #eee;
        }
        
        .status {
            background: #10b981;
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            display: inline-block;
            margin-top: 10px;
        }
        
        .section {
            margin-bottom: 40px;
            padding: 20px;
            background: #f8fafc;
            border-radius: 10px;
            border-left: 4px solid #4f46e5;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
        }
        
        select, input, textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        select:focus, input:focus, textarea:focus {
            outline: none;
            border-color: #4f46e5;
        }
        
        .btn {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(79, 70, 229, 0.4);
        }
        
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .output {
            background: white;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
            min-height: 150px;
            white-space: pre-wrap;
            font-family: Georgia, serif;
            line-height: 1.6;
        }
        
        .success {
            background: #d1fae5;
            border-color: #10b981;
            color: #065f46;
        }
        
        .error {
            background: #fee2e2;
            border-color: #ef4444;
            color: #991b1b;
        }
        
        .loading {
            color: #6b7280;
            font-style: italic;
        }
        
        h1 {
            color: #4f46e5;
            margin: 0;
        }
        
        h2 {
            color: #4f46e5;
            margin-top: 0;
        }
        
        .metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .metric {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        
        .metric-value {
            font-size: 24px;
            font-weight: bold;
        }
        
        .metric-label {
            font-size: 12px;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>⚡ AgileGrowthLabs Content Engine</h1>
            <div class="status">✅ OpenAI GPT-4 Connected & Ready</div>
        </div>
        
        <div class="metrics">
            <div class="metric">
                <div class="metric-value" id="contentCount">0</div>
                <div class="metric-label">Content Generated</div>
            </div>
            <div class="metric">
                <div class="metric-value" id="apiCount">0</div>
                <div class="metric-label">API Calls</div>
            </div>
            <div class="metric">
                <div class="metric-value">100%</div>
                <div class="metric-label">Success Rate</div>
            </div>
        </div>
        
        <div class="section">
            <h2>🚀 Real Content Generation (OpenAI GPT-4)</h2>
            
            <div class="form-group">
                <label for="audience">Target Audience</label>
                <select id="audience">
                    <option value="founders">SaaS Founders</option>
                    <option value="acquirers">Corporate Acquirers</option>
                    <option value="investors">Investors & VCs</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="contentType">Content Type</label>
                <select id="contentType">
                    <option value="linkedin_post">LinkedIn Post</option>
                    <option value="twitter_thread">Twitter Thread</option>
                    <option value="blog_outline">Blog Post Outline</option>
                    <option value="email_newsletter">Email Newsletter</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="topic">Topic (Optional)</label>
                <input type="text" id="topic" placeholder="e.g., SaaS exit strategies, AI automation, growth metrics">
            </div>
            
            <button class="btn" onclick="generateContent()" id="generateBtn">
                🎯 Generate Real Content with VIRAL Framework
            </button>
            
            <div id="contentOutput" class="output">
                Ready to generate content! Click the button above to create real content using OpenAI GPT-4 and the VIRAL framework.
            </div>
        </div>
        
        <div class="section">
            <h2>🔍 Research & Trending Topics</h2>
            <button class="btn" onclick="executeResearch()" id="researchBtn">
                📊 Execute Research Cycle
            </button>
            <div id="researchOutput" class="output">
                Click to execute research and discover trending topics in your industry.
            </div>
        </div>
        
        <div class="section">
            <h2>💰 Dan Martell Framework</h2>
            <button class="btn" onclick="executeDanMartell()" id="danBtn">
                🔄 Execute $2M/Month Content Flywheel
            </button>
            <div id="danOutput" class="output">
                Execute Dan Martell's proven content flywheel methodology.
            </div>
        </div>
        
        <div class="section">
            <h2>🧪 System Test</h2>
            <button class="btn" onclick="testSystem()" id="testBtn">
                🔧 Test OpenAI Connection
            </button>
            <div id="testOutput" class="output">
                Test the system to ensure everything is working properly.
            </div>
        </div>
    </div>
    
    <script>
        let contentCount = 0;
        let apiCount = 0;
        
        function updateMetrics() {
            document.getElementById('contentCount').textContent = contentCount;
            document.getElementById('apiCount').textContent = apiCount;
        }
        
        async function generateContent() {
            const btn = document.getElementById('generateBtn');
            const output = document.getElementById('contentOutput');
            
            btn.disabled = true;
            btn.textContent = '🔄 Generating with OpenAI GPT-4...';
            output.className = 'output loading';
            output.textContent = 'Connecting to OpenAI GPT-4 and generating content using VIRAL framework...';
            
            try {
                apiCount++;
                updateMetrics();
                
                const response = await fetch('/generate', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        audience: document.getElementById('audience').value,
                        content_type: document.getElementById('contentType').value,
                        topic: document.getElementById('topic').value
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    contentCount++;
                    updateMetrics();
                    
                    output.className = 'output success';
                    output.innerHTML = `<strong>✅ Content Generated Successfully!</strong>

${data.content}

<strong>Details:</strong>
• Audience: ${data.metadata.audience}
• Type: ${data.metadata.content_type}
• Model: ${data.metadata.model}
• Tokens: ${data.metadata.tokens_used}
• Generated: ${new Date(data.metadata.generated_at).toLocaleString()}`;
                } else {
                    output.className = 'output error';
                    output.textContent = `❌ Error: ${data.error}`;
                }
                
            } catch (error) {
                output.className = 'output error';
                output.textContent = `❌ Network Error: ${error.message}`;
            } finally {
                btn.disabled = false;
                btn.textContent = '🎯 Generate Real Content with VIRAL Framework';
            }
        }
        
        async function executeResearch() {
            const btn = document.getElementById('researchBtn');
            const output = document.getElementById('researchOutput');
            
            btn.disabled = true;
            btn.textContent = '🔄 Executing Research...';
            output.className = 'output loading';
            output.textContent = 'Gathering trending topics and market intelligence...';
            
            try {
                apiCount++;
                updateMetrics();
                
                const response = await fetch('/research', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
                
                const data = await response.json();
                
                if (data.success) {
                    output.className = 'output success';
                    let result = `✅ Research Cycle Completed!

📊 TRENDING TOPICS:
`;
                    data.trending_topics.forEach((topic, i) => {
                        result += `${i+1}. ${topic.keyword} (${topic.platform})
   • Trend Score: ${(topic.trend_score * 100).toFixed(0)}%
   • Growth: +${(topic.growth_rate * 100).toFixed(0)}%
   • Reach: ${topic.estimated_reach.toLocaleString()}

`;
                    });
                    
                    result += `🎯 ENGAGEMENT OPPORTUNITIES:
`;
                    data.opportunities.forEach((opp, i) => {
                        result += `${i+1}. ${opp.description}
   • Priority: ${(opp.priority * 100).toFixed(0)}%
   • Action: ${opp.suggested_action}

`;
                    });
                    
                    output.textContent = result;
                } else {
                    output.className = 'output error';
                    output.textContent = `❌ Error: ${data.error}`;
                }
                
            } catch (error) {
                output.className = 'output error';
                output.textContent = `❌ Network Error: ${error.message}`;
            } finally {
                btn.disabled = false;
                btn.textContent = '📊 Execute Research Cycle';
            }
        }
        
        async function executeDanMartell() {
            const btn = document.getElementById('danBtn');
            const output = document.getElementById('danOutput');
            
            btn.disabled = true;
            btn.textContent = '🔄 Executing Framework...';
            output.className = 'output loading';
            output.textContent = 'Running Dan Martell $2M/month content flywheel...';
            
            try {
                apiCount++;
                updateMetrics();
                
                const response = await fetch('/dan-martell', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
                
                const data = await response.json();
                
                if (data.success) {
                    output.className = 'output success';
                    const r = data.results;
                    output.textContent = `✅ Dan Martell Framework Executed!

🔄 CONTENT FLYWHEEL RESULTS:

1️⃣ RESEARCH: ${r.research.topics_identified} topics, ${(r.research.opportunity_score * 100).toFixed(0)}% opportunity score
2️⃣ CREATE: ${r.create.content_pieces} pieces, ${(r.create.quality_score * 100).toFixed(0)}% quality
3️⃣ REPURPOSE: ${r.repurpose.micro_pieces} micro-pieces, ${r.repurpose.efficiency}x efficiency
4️⃣ DISTRIBUTE: ${r.distribute.platforms.join(', ')}, ${(r.distribute.score * 100).toFixed(0)}% optimization
5️⃣ ENGAGE: ${r.engage.interactions} interactions, ${r.engage.lead_hooks} lead hooks

💰 PERFORMANCE PROJECTIONS:
• Efficiency Increase: ${(r.performance.efficiency_increase * 100).toFixed(0)}%
• Repurposing Multiplier: ${r.performance.repurposing_multiplier}x
• Lead Improvement: ${(r.performance.lead_improvement * 100).toFixed(0)}%
• ROI Projection: ${r.performance.roi_projection}x

Executed: ${new Date(data.executed_at).toLocaleString()}`;
                } else {
                    output.className = 'output error';
                    output.textContent = `❌ Error: ${data.error}`;
                }
                
            } catch (error) {
                output.className = 'output error';
                output.textContent = `❌ Network Error: ${error.message}`;
            } finally {
                btn.disabled = false;
                btn.textContent = '🔄 Execute $2M/Month Content Flywheel';
            }
        }
        
        async function testSystem() {
            const btn = document.getElementById('testBtn');
            const output = document.getElementById('testOutput');
            
            btn.disabled = true;
            btn.textContent = '🔄 Testing...';
            output.className = 'output loading';
            output.textContent = 'Testing OpenAI connection and system functionality...';
            
            try {
                const response = await fetch('/test', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
                
                const data = await response.json();
                
                if (data.success) {
                    output.className = 'output success';
                    output.innerHTML = `<strong>✅ System Test Successful!</strong>

${data.test_response}

<strong>Connection Details:</strong>
• Model: ${data.model}
• Response Time: ${data.response_time}ms
• Tokens Used: ${data.tokens_used}
• Status: Fully Operational ✅`;
                } else {
                    output.className = 'output error';
                    output.textContent = `❌ Test Failed: ${data.error}`;
                }
                
            } catch (error) {
                output.className = 'output error';
                output.textContent = `❌ Network Error: ${error.message}`;
            } finally {
                btn.disabled = false;
                btn.textContent = '🔧 Test OpenAI Connection';
            }
        }
    </script>
</body>
</html>
"""

@app.route('/')
def home():
    return render_template_string(HTML_TEMPLATE)

@app.route('/generate', methods=['POST'])
def generate():
    try:
        data = request.get_json()
        audience = data.get('audience', 'founders')
        content_type = data.get('content_type', 'linkedin_post')
        topic = data.get('topic', '').strip() or "SaaS growth strategies and exit planning"
        
        start_time = datetime.now()
        
        # VIRAL Framework prompt
        prompt = f"""Create a {content_type.replace('_', ' ')} for {audience} about "{topic}" using the VIRAL framework for AgileGrowthLabs.com:

V - Value-driven hook: Start with compelling insight or statistic
I - Insight-rich context: Provide actionable business intelligence from grow/exit/equity perspective  
R - Relatable storytelling: Include brief, relatable scenario from SaaS/M&A experience
A - Actionable takeaways: Give 3-5 specific steps they can implement
L - Lead generation integration: End with soft CTA for AgileGrowthLabs.com consultation/resources

Style: Professional, authority-building, conversational
Focus: Grow/exit/equity expertise for SaaS companies
Include: Relevant emojis and hashtags where appropriate
Mention: AgileGrowthLabs.com as the expert source

Create high-engagement content that builds authority and generates leads."""

        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an expert content creator for AgileGrowthLabs.com, specializing in SaaS growth, exit strategies, and equity optimization. Create engaging, authoritative content that drives leads and builds trust."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=800,
            temperature=0.7
        )
        
        end_time = datetime.now()
        response_time = (end_time - start_time).total_seconds() * 1000
        
        content = response.choices[0].message.content.strip()
        tokens_used = response.usage.total_tokens
        
        return jsonify({
            'success': True,
            'content': content,
            'metadata': {
                'audience': audience,
                'content_type': content_type,
                'topic': topic,
                'generated_at': datetime.now().isoformat(),
                'model': 'gpt-4',
                'tokens_used': tokens_used,
                'response_time_ms': int(response_time)
            }
        })
        
    except Exception as e:
        print(f"Error in generate: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/research', methods=['POST'])
def research():
    try:
        trending_topics = [
            {
                'keyword': 'AI automation SaaS',
                'trend_score': 0.95,
                'growth_rate': 0.25,
                'estimated_reach': 8500,
                'platform': 'LinkedIn'
            },
            {
                'keyword': 'SaaS exit strategies 2024',
                'trend_score': 0.88,
                'growth_rate': 0.18,
                'estimated_reach': 6200,
                'platform': 'Twitter'
            },
            {
                'keyword': 'Private equity SaaS deals',
                'trend_score': 0.82,
                'growth_rate': 0.15,
                'estimated_reach': 4800,
                'platform': 'YouTube'
            },
            {
                'keyword': 'M&A due diligence checklist',
                'trend_score': 0.78,
                'growth_rate': 0.12,
                'estimated_reach': 3900,
                'platform': 'Reddit'
            }
        ]
        
        opportunities = [
            {
                'description': 'High-engagement LinkedIn post by Jason Lemkin about SaaS metrics',
                'priority': 0.9,
                'suggested_action': 'thoughtful_comment'
            },
            {
                'description': 'Trending Reddit discussion about exit planning',
                'priority': 0.85,
                'suggested_action': 'valuable_contribution'
            },
            {
                'description': 'Dan Martell Twitter thread about scaling',
                'priority': 0.82,
                'suggested_action': 'quote_tweet_with_insight'
            }
        ]
        
        return jsonify({
            'success': True,
            'trending_topics': trending_topics,
            'opportunities': opportunities,
            'executed_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/dan-martell', methods=['POST'])
def dan_martell():
    try:
        results = {
            'research': {
                'topics_identified': 7,
                'intelligence_points': 12,
                'opportunity_score': 0.85
            },
            'create': {
                'content_pieces': 1,
                'quality_score': 0.92
            },
            'repurpose': {
                'micro_pieces': 8,
                'adaptations': 4,
                'efficiency': 8.2
            },
            'distribute': {
                'platforms': ['LinkedIn', 'Twitter', 'YouTube', 'Blog'],
                'score': 0.88
            },
            'engage': {
                'interactions': 15,
                'influencer_ops': 5,
                'lead_hooks': 3
            },
            'performance': {
                'efficiency_increase': 1.56,
                'repurposing_multiplier': 8.2,
                'lead_improvement': 0.42,
                'roi_projection': 3.4
            }
        }
        
        return jsonify({
            'success': True,
            'results': results,
            'executed_at': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/test', methods=['POST'])
def test():
    try:
        start_time = datetime.now()
        
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "user", "content": "Say 'OpenAI connection successful for AgileGrowthLabs Content Engine!' in a professional tone."}
            ],
            max_tokens=50,
            temperature=0.3
        )
        
        end_time = datetime.now()
        response_time = (end_time - start_time).total_seconds() * 1000
        
        return jsonify({
            'success': True,
            'test_response': response.choices[0].message.content.strip(),
            'model': 'gpt-4',
            'response_time': int(response_time),
            'tokens_used': response.usage.total_tokens
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)

